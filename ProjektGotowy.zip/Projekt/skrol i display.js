
//==========SCROLLOWANIE PRZYCISKAMI==========

jQuery(function ($){
    $.scrollTo(0);
    $('.link4').click(function (e){e.preventDefault();$.scrollTo($('#n4'),500)})
    $('.link3').click(function (e){e.preventDefault();$.scrollTo($('#n3'),500)})
    $('.link2').click(function (e){e.preventDefault();$.scrollTo($('#n2'),500)})
    $('.link1').click(function (e){e.preventDefault();$.scrollTo($('#n1'),500)})
    $('.top').click(function (e){e.preventDefault();$.scrollTo(0,500)})
})

//==========POKAZYWANIE/UKRYWANIE MENU==========

// $(window).scroll(function ()
// {
//         if($(this).scrollTop()>300) {
//             $('.side-menu-container').fadeIn();
//             if($(window).outerWidth()>=1501){
//                 {$('.maly').hide();}
//                 {$('.sredni').hide();}
//                 {$('.duzy').fadeOut();}
//             }
//             else if($(window).outerWidth()>=1101 && $(window).outerWidth()<=1500)
//             {
//                 {$('.maly').hide();}
//                 {$('.sredni').fadeOut();}
//                 {$('.duzy').hide();}
//             }
//             else{
//                 {$('.maly').fadeOut();}
//                 {$('.sredni').hide();}
//                 {$('.duzy').hide();}
//             }
//         }
//         else{
//             $('.side-menu-container').fadeOut();
//             if($(window).outerWidth()>=1501){
//                 {$('.maly').hide();}
//                 {$('.sredni').hide();}
//                 {$('.duzy').fadeIn();}
//             }
//             else if($(window).outerWidth()>=1101 && $(window).outerWidth()<=1500)
//             {
//                 {$('.maly').hide();}
//                 {$('.sredni').fadeIn();}
//                 {$('.duzy').hide();}
//             }
//             else{
//                 {$('.maly').fadeIn();}
//                 {$('.sredni').hide();}
//                 {$('.duzy').hide();}
//             }
//         }
//    });$(window).resize(function ()
// {
//         if($(this).scrollTop()>300) {
//             $('.side-menu-container').fadeIn();
//             if($(window).outerWidth()>=1501){
//                 {$('.maly').hide();}
//                 {$('.sredni').hide();}
//                 {$('.duzy').fadeOut();}
//             }
//             else if($(window).outerWidth()>=1101 && $(window).outerWidth()<=1500)
//             {
//                 {$('.maly').hide();}
//                 {$('.sredni').fadeOut();}
//                 {$('.duzy').hide();}
//             }
//             else{
//                 {$('.maly').fadeOut();}
//                 {$('.sredni').hide();}
//                 {$('.duzy').hide();}
//             }
//         }
//         else{
//             $('.side-menu-container').fadeOut();
//             if($(window).outerWidth()>=1501){
//                 {$('.maly').hide();}
//                 {$('.sredni').hide();}
//                 {$('.duzy').fadeIn();}
//             }
//             else if($(window).outerWidth()>=1101 && $(window).outerWidth()<=1500)
//             {
//                 {$('.maly').hide();}
//                 {$('.sredni').fadeIn();}
//                 {$('.duzy').hide();}
//             }
//             else{
//                 {$('.maly').fadeIn();}
//                 {$('.sredni').hide();}
//                 {$('.duzy').hide();}
//             }
//         }
//    });

$(window).scroll(function ()
{
    if($(this).width()>=1501){
        { $('.sredni').hide();}
        { $('.maly').hide();}
        if($(this).scrollTop()>300) {
            { $('.duzy').fadeOut();}
            { $('.side-menu-container').fadeIn();}
        }
        else{
            { $('.duzy').fadeIn();}
            { $('.side-menu-container').fadeOut();}
        }}
    if($(this).width()>=1101 && $(this).width()<=1500){
        { $('.duzy').hide();}
        { $('.maly').hide();}
        if($(this).scrollTop()>300) {
            { $('.sredni').fadeOut();}
            { $('.side-menu-container').fadeIn();}
        }
        else{
            { $('.sredni').fadeIn();}
            { $('.side-menu-container').fadeOut();}
   }}if($(this).width()<=1100){
    { $('.duzy').hide();}
    { $('.sredni').hide();}
        if($(this).scrollTop()>300) {
            { $('.maly').fadeOut();}
            { $('.side-menu-container').fadeIn();}
        }
        else{
            { $('.maly').fadeIn();}
            { $('.side-menu-container').fadeOut();}
   }}});$(window).resize(function ()
{
    if($(this).width()>=1501){
        { $('.sredni').hide();}
        { $('.maly').hide();}
        if($(this).scrollTop()>300) {
            { $('.duzy').fadeOut();}
            { $('.side-menu-container').fadeIn();}
        }
        else{
            { $('.duzy').fadeIn();}
            { $('.side-menu-container').fadeOut();}
        }}
    if($(this).width()>=1101 && $(this).width()<=1500){
        { $('.duzy').hide();}
        { $('.maly').hide();}
        if($(this).scrollTop()>300) {
            { $('.sredni').fadeOut();}
            { $('.side-menu-container').fadeIn();}
        }
        else{
            { $('.sredni').fadeIn();}
            { $('.side-menu-container').fadeOut();}
   }}if($(this).width()<=1100){
    { $('.duzy').hide();}
    { $('.sredni').hide();}
        if($(this).scrollTop()>300) {
            { $('.maly').fadeOut();}
            { $('.side-menu-container').fadeIn();}
        }
        else{
            { $('.maly').fadeIn();}
            { $('.side-menu-container').fadeOut();}
   }}});


// ==========WIECZNY OGIEN==========
// $(window).resize(function (){
//     $('.duzy').hide();
//     $('.sredni').hide();
//     $('.maly').hide();
//
// });

$(window).scroll(function () {
    var p = $('#n4').first();
    var position = p.position();

    if ($(this).scrollTop() > position.top) {
        $('.wrapper').fadeIn();
        }
    else {$('.wrapper').fadeOut();}
})
$(document).ready(function (){
    $('.wrapper').hide();

});
