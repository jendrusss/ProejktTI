
// ==========WYSOKOSCI (niepotrzebne)==========
function getOffset(el) {
    const rect = el.getBoundingClientRect();
    return {
    top: rect.top
};}






//==========SLIDER==========
var i = 2;
function switchImages() {
    document.getElementById("zamki").src = "Images/" + i + ".gif";
    if (i == 9) {
    i = 1
}
    else i++;}
    setInterval(switchImages, 2500);






//==========SUROWCE ONCLICK==========


var liob = document.getElementsByClassName("obrsur");
var opob = document.getElementsByClassName("opis");

function skrot(k){if (liob[k].style.display === "none") {
    liob[k].style.display = "block";
    opob[k].style.display = "block";
} else {
    liob[k].style.display = "none";
    opob[k].style.display = "none";
}}

function s1() {
    for (let i = 0; i < liob.length; i++) {
        if (i == 0) { skrot(i);
             }
        else {
            liob[i].style.display = "none";
            opob[i].style.display = "none";
        }
    }
}function s2() {
    for (let i = 0; i < liob.length; i++) {
        if (i == 1) {skrot(i);
        } else {
            liob[i].style.display = "none";
            opob[i].style.display = "none";
        }
    }
}function s3() {
    for (let i = 0; i < liob.length; i++) {
        if (i == 2) {skrot(i);
        } else {
            liob[i].style.display = "none";
            opob[i].style.display = "none";
        }
    }
}function s4() {
    for (let i = 0; i < liob.length; i++) {
        if (i == 3) {skrot(i);
        } else {
            liob[i].style.display = "none";
            opob[i].style.display = "none";
        }
    }
}function s5() {
    for (let i = 0; i < liob.length; i++) {
        if (i == 4) {skrot(i);
        } else {
            liob[i].style.display = "none";
            opob[i].style.display = "none";
        }
    }
}function s6() {
    for (let i = 0; i < liob.length; i++) {
        if (i == 5) {skrot(i);
        } else {
            liob[i].style.display = "none";
            opob[i].style.display = "none";
        }
    }
}function s7() {
    for (let i = 0; i < liob.length; i++) {
        if (i == 6) {skrot(i);
        } else {
            liob[i].style.display = "none";
            opob[i].style.display = "none";
        }
    }
}

// ==========WYBUCH==========

$(document).ready(function (){
    let cialo=document.getElementById('cialo');
    let i=1;
    $('.wrapper').click(function (){$('#bomber'+i).explode({"minWidth":1,"maxWidth":10,"radius":235,"minRadius":54,"release":true,"fadeTime":100,"recycle":false,"recycleDelay":11,"explodeTime":231,"round":false,"minAngle":0,"maxAngle":360,"gravity":8,"groundDistance":100});
        i++;
        if(i==9){
            alert("Strona zostala zepsuta")
            cialo.style.transform="rotate(180deg)";
        }
    })

})


