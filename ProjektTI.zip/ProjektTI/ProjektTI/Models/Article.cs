﻿using System.ComponentModel.DataAnnotations;

namespace ProjektTI.Models
{
    /// <summary>
    /// model dla Artykułu
    /// </summary>
    public class Article
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Title { get; set; }
        public string Tags { get; set; }
        public string Author { get; set; }
        public string Content { get; set; }
    }
}
