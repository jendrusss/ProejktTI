﻿using System.ComponentModel.DataAnnotations;

namespace ProjektTI.Models
{/// <summary>
/// Model Team
/// </summary>
    public class Team
    {
        [Key]
        public string Name { get; set; }
        public int GamesPlayed { get; set; } = 0;
        public int Points { get; set; } = 0;
        public int GoalsScored { get; set; } = 0;
        public int GoalsConceded { get; set; } = 0;
        public List<Player> Players { get; set; }=new List<Player>();
        public virtual string GroupName { get; set; }
    }
}
