﻿using System.ComponentModel.DataAnnotations;

namespace ProjektTI.Models
{
    /// <summary>
    /// Model Group - w projekcie jako Liga- pierwotnie miala to byc Grupa (np. Grupa A na mundialu) ale w trakcie pracy przekształciła się w ligę, mimo postanowilismy nazwe tego modelu jako Group
    /// </summary>
    public class Group
    {
        [Key]
        public string Name { get; set; }
        public List<Team> Teams { get; set; }=new List<Team>();
    }
}
