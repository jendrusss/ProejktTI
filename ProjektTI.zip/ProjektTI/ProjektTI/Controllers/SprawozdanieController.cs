﻿using Microsoft.AspNetCore.Mvc;

namespace ProjektTI.Controllers
{
    /// <summary>
    /// Kontroler przekierowujacy do widoku z opisem projektu
    /// </summary>
    public class SprawozdanieController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
