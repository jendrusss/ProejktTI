﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ProjektTI.Data;
using ProjektTI.Models;

namespace ProjektTI.Controllers
{
    /// <summary>
    /// kontroler dla modelu: Artykuł - w tym Kontrolerze opisane zostana wszystkie podstawowe funkcje, w pozostalych zostana uwzglednione tylko roznice wzgledem podstawowych funkcji CRUD
    /// </summary>
    public class ArticlesController : Controller
    {
        private readonly ApplicationDbContext _context;

        /// <summary>
        /// stworzenie odwolania do bazy danych
        /// </summary>

        public ArticlesController(ApplicationDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// stworzenie widoku dla "Index" wyswietlenie listy artykulow
        /// </summary>

        public async Task<IActionResult> Index()
        {
            List<Article> articles = new List<Article>();
            articles.AddRange(_context.Article);
            ViewBag.Articles = articles;
              return _context.Article != null ? 
                          View(await _context.Article.ToListAsync()) :
                          Problem("Entity set 'ApplicationDbContext.Article'  is null.");
        }

        // GET: Articles/Details/5
        /// <summary>
        /// stworzenie widoku dla funkcji Details, sprawdzenie czy dany Artykul istenieje
        /// </summary>

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Article == null)
            {
                return NotFound();
            }

            var article = await _context.Article
                .FirstOrDefaultAsync(m => m.Id == id);
            if (article == null)
            {
                return NotFound();
            }

            return View(article);
        }

        // GET: Articles/Create
        /// <summary>
        /// stworzenie widoku do tworzenia nowego Artykulu
        /// </summary>
        public IActionResult Create()
        {
            return View();
        }

        // POST: Articles/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        /// <summary>
        /// Sprawdzenie czy Model jest poprawny, jesli tak dodajemy go do bazy danych
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Title,Tags,Author,Content")] Article article)
        {
            if (ModelState.IsValid)
            {
                _context.Add(article);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(article);
        }

        // GET: Articles/Edit/5
        /// <summary>
        /// Widok edycji artykulu, sprawdzamy czy artykul o danym id istnieeje
        /// </summary>

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Article == null)
            {
                return NotFound();
            }

            var article = await _context.Article.FindAsync(id);
            if (article == null)
            {
                return NotFound();
            }
            return View(article);
        }

        // POST: Articles/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        /// <summary>
        /// Zapisanie edytowanych zmian do bazy danych, po uprzednim sprawdzeniu poprawnosci artykulu
        /// </summary>

        [HttpPost]
        [ValidateAntiForgeryToken]

        
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,Tags,Author,Content")] Article article)
        {
            if (id != article.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(article);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ArticleExists(article.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(article);
        }

        // GET: Articles/Delete/5
        /// <summary>
        /// widok sluzacy do usuwania artykulu
        /// </summary>

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Article == null)
            {
                return NotFound();
            }

            var article = await _context.Article
                .FirstOrDefaultAsync(m => m.Id == id);
            if (article == null)
            {
                return NotFound();
            }

            return View(article);
        }

        // POST: Articles/Delete/5
        /// <summary>
        /// potwierdzenie usuniecia artykulu
        /// </summary>

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Article == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Article'  is null.");
            }
            var article = await _context.Article.FindAsync(id);
            if (article != null)
            {
                _context.Article.Remove(article);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ArticleExists(int id)
        {
          return (_context.Article?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
