﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ProjektTI.Data;
using ProjektTI.Models;

namespace ProjektTI.Controllers
{
    /// <summary>
    /// kontroler dla modelu Team
    /// </summary>
    public class TeamsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public TeamsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Teams
        /// <summary>
        /// przed przekazaniem listy zespołów do Widoku sortujemy je malejąco względem liczby posiadanych przez nie punktow
        /// </summary>
        public async Task<IActionResult> Index()
        {
            var teams = await _context.Teams.ToListAsync();
            teams = teams.OrderByDescending(x => x.Points).ToList();
              return _context.Teams != null ? 
                          View(teams) :
                          Problem("Entity set 'ApplicationDbContext.Teams'  is null.");
        }

        // GET: Teams/Details/5
        /// <summary>
        /// w szczegolach druzyny ma wyswietlac sie lista zawodnikow grajacych w niej - zostaje ona przekazana przez ViewBaga
        /// </summary>

        public async Task<IActionResult> Details(string id)
        {
            List<Player> players = new List<Player>();
            players.AddRange(_context.Player);
            ViewBag.Players = players;
            if (id == null || _context.Teams == null)
            {
                return NotFound();
            }

            var team = await _context.Teams
                .FirstOrDefaultAsync(m => m.Name == id);
            if (team == null)
            {
                return NotFound();
            }

            return View(team);
        }
        /// <summary>
        /// przekazanie listy typu SelectListItem w celu otworzenia dropdown listy lig w tworzeniu druzyny
        /// </summary>
        // GET: Teams/Create
        public IActionResult Create()
        {
            List<Group> groups = new List<Group>();
            groups.AddRange(_context.Groups);
            List<SelectListItem> gotowe = new List<SelectListItem>();
            foreach (var group in groups)
            {
                SelectListItem helper = new SelectListItem();
                helper.Value = group.Name.ToString();
                helper.Text = group.Name.ToString();
                gotowe.Add(helper);
            }
            ViewBag.GroupName = gotowe;


            return View();
        }

        // POST: Teams/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Name,GamesPlayed,Points,GoalsScored,GoalsConceded,GroupName")] Team team)
        {
            List<Group> groups = new List<Group>();
            groups.AddRange(_context.Groups);
            List<SelectListItem> gotowe = new List<SelectListItem>();
            foreach (var group in groups)
            {
                SelectListItem helper = new SelectListItem();
                helper.Value = group.Name.ToString();
                helper.Text = group.Name.ToString();
                gotowe.Add(helper);
            }
            ViewBag.GroupName = gotowe;

            if (ModelState.IsValid)
            {
                _context.Add(team);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(team);
        }

        // GET: Teams/Edit/5
        /// <summary>
        /// Tak samo jak w Create używamy ViewBaga zeby móc stworzyć dropdown list
        /// </summary>

        public async Task<IActionResult> Edit(string id)
        {
            List<Group> groups = new List<Group>();
            groups.AddRange(_context.Groups);
            List<SelectListItem> gotowe = new List<SelectListItem>();
            foreach (var groupA in groups)
            {
                SelectListItem helper = new SelectListItem();
                helper.Value = groupA.Name.ToString();
                helper.Text = groupA.Name.ToString();
                gotowe.Add(helper);
            }
            ViewBag.GroupName = gotowe;
            if (id == null || _context.Teams == null)
            {
                return NotFound();
            }

            var team = await _context.Teams.FindAsync(id);
            if (team == null)
            {
                return NotFound();
            }
            return View(team);
        }

        // POST: Teams/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("Name,GamesPlayed,Points,GoalsScored,GoalsConceded,GroupName")] Team team)
        {
            if (id != team.Name)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(team);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TeamExists(team.Name))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(team);
        }

        // GET: Teams/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null || _context.Teams == null)
            {
                return NotFound();
            }

            var team = await _context.Teams
                .FirstOrDefaultAsync(m => m.Name == id);
            if (team == null)
            {
                return NotFound();
            }

            return View(team);
        }

        // POST: Teams/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            if (_context.Teams == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Teams'  is null.");
            }
            var team = await _context.Teams.FindAsync(id);
            if (team != null)
            {
                _context.Teams.Remove(team);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TeamExists(string id)
        {
          return (_context.Teams?.Any(e => e.Name == id)).GetValueOrDefault();
        }
    }
}
