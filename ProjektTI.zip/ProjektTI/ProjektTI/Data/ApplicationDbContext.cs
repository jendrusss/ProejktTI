﻿
using Microsoft.EntityFrameworkCore;
using ProjektTI.Models;

namespace ProjektTI.Data
{
    public class ApplicationDbContext:DbContext
    {
        /// <summary>
        /// stworzenie odniesienia do bazy danych dla modeli
        /// </summary>

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options):base(options) { }
        public DbSet<Team>Teams { get; set; }
        public DbSet<Group>Groups { get; set; }
        public DbSet<ProjektTI.Models.Player>? Player { get; set; }
        public DbSet<ProjektTI.Models.Article>? Article { get; set; }

    }
}
