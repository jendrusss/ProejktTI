﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProjektTI.Migrations
{
    public partial class GroupToLeagueTransition : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Teams_Groups_GroupName",
                table: "Teams");

            migrationBuilder.DropIndex(
                name: "IX_Teams_GroupName",
                table: "Teams");

            migrationBuilder.AddColumn<string>(
                name: "GroupName1",
                table: "Teams",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "Groups",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(1)");

            migrationBuilder.CreateTable(
                name: "Article",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Tags = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Author = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Content = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Article", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Teams_GroupName1",
                table: "Teams",
                column: "GroupName1");

            migrationBuilder.AddForeignKey(
                name: "FK_Teams_Groups_GroupName1",
                table: "Teams",
                column: "GroupName1",
                principalTable: "Groups",
                principalColumn: "Name");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Teams_Groups_GroupName1",
                table: "Teams");

            migrationBuilder.DropTable(
                name: "Article");

            migrationBuilder.DropIndex(
                name: "IX_Teams_GroupName1",
                table: "Teams");

            migrationBuilder.DropColumn(
                name: "GroupName1",
                table: "Teams");

            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "Groups",
                type: "nvarchar(1)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.CreateIndex(
                name: "IX_Teams_GroupName",
                table: "Teams",
                column: "GroupName");

            migrationBuilder.AddForeignKey(
                name: "FK_Teams_Groups_GroupName",
                table: "Teams",
                column: "GroupName",
                principalTable: "Groups",
                principalColumn: "Name",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
