﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProjektTI.Migrations
{
    public partial class final : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
